package com.ejemplo.miprimeraapp;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Switch;
import android.widget.SeekBar;
import android.widget.Toast;
import android.graphics.Color;
import android.view.Gravity;

public class MainActivity extends Activity {

    private SharedPreferences preferencias;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(android.R.style.Theme_DeviceDefault_NoActionBar);
        super.onCreate(savedInstanceState);

        // Inicializamos la memoria interna de la app
        preferencias = getSharedPreferences("ConfigPanel", Context.MODE_PRIVATE);

        // 1. Contenedor Principal (Fondo Negro)
        LinearLayout contenedor = new LinearLayout(this);
        contenedor.setOrientation(LinearLayout.VERTICAL);
        contenedor.setBackgroundColor(Color.parseColor("#121212"));
        contenedor.setGravity(Gravity.CENTER_HORIZONTAL);
        contenedor.setPadding(60, 80, 60, 80);

        // 2. Título del Panel
        TextView textMenu = new TextView(this);
        textMenu.setText("PANEL DE CONTROL PRO");
        textMenu.setTextSize(24);
        textMenu.setTextColor(Color.parseColor("#00FF88"));
        textMenu.setGravity(Gravity.CENTER);
        textMenu.setPadding(0, 0, 0, 80);

        // 3. INTERRUPTOR (SWITCH)
        Switch switchFuncion = new Switch(this);
        switchFuncion.setText("Optimización Avanzada  ");
        switchFuncion.setTextColor(Color.WHITE);
        switchFuncion.setTextSize(18);
        switchFuncion.setPadding(0, 40, 0, 40);
        
        // Cargar estado guardado del Switch
        boolean estadoGuardado = preferencias.getBoolean("switch_estado", false);
        switchFuncion.setChecked(estadoGuardado);

        // Acción al mover el Switch
        switchFuncion.setOnCheckedChangeListener((buttonView, isChecked) -> {
            SharedPreferences.Editor editor = preferencias.edit();
            editor.putBoolean("switch_estado", isChecked);
            editor.apply(); // Guarda en la memoria del cel

            if (isChecked) {
                Toast.makeText(this, "Optimización activada al 100%", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Optimización desactivada", Toast.LENGTH_SHORT).show();
            }
        });

        // 4. TEXTO DE LA BARRA DE PORCENTAJE
        TextView textPorcentaje = new TextView(this);
        int progresoGuardado = preferencias.getInt("barra_progreso", 50); // 50 por defecto
        textPorcentaje.setText("Ajuste de Sensibilidad: " + progresoGuardado + "%");
        textPorcentaje.setTextColor(Color.WHITE);
        textPorcentaje.setTextSize(16);
        textPorcentaje.setPadding(0, 80, 0, 20);

        // 5. BARRA DESLIZABLE (SEEKBAR) DE 0 A 100%
        SeekBar barraAjuste = new SeekBar(this);
        barraAjuste.setMax(100); // Valor máximo 100%
        barraAjuste.setProgress(progresoGuardado);

        // Acción al deslizar la barra
        barraAjuste.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Actualiza el texto en tiempo real mientras deslizas
                textPorcentaje.setText("Ajuste de Sensibilidad: " + progress + "%");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Guarda el porcentaje final cuando sueltas el dedo
                int progresoFinal = seekBar.getProgress();
                SharedPreferences.Editor editor = preferencias.edit();
                editor.putInt("barra_progreso", progresoFinal);
                editor.apply();
                
                Toast.makeText(MainActivity.this, "Guardado al " + progresoFinal + "%", Toast.LENGTH_SHORT).show();
            }
        });

        // Metemos todos los nuevos elementos a la interfaz
        contenedor.addView(textMenu);
        contenedor.addView(switchFuncion);
        contenedor.addView(textPorcentaje);
        contenedor.addView(barraAjuste);
        
        setContentView(contenedor);
    }
}
